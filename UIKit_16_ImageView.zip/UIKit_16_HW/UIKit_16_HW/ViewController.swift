//
//  ViewController.swift
//  UIKit_16_HW

/*
 1. Повторить что было в уроке
 2. Создать VC в котором находятся 6 фото
 3. Создать VC 2 сделать UIImageView на пол экрана
 4. По нажатию на фото VC1 (через UITapGestureRecognizer) перейти на VC 2 и передать фото на которое нажали
 5. В VC 2 сделать Picker которой позволяет выбрать Content Mode для фото
 6. В VC 2 сделать слайдер которые регулирует alpha для фото
 */


import UIKit

class ViewController: UIViewController {
    
    let myImageView1 = UIImageView()
    let myImageView2 = UIImageView()
    let myImageView3 = UIImageView()
    let myImageView4 = UIImageView()
    let myImageView5 = UIImageView()
    let myImageView6 = UIImageView()
    var selectedImage:UIImageView?
    
 
    let image1 = UIImage(named: "1_kat")
    let image2 = UIImage(named: "2_kat")
    let image3 = UIImage(named: "3_kat")
    let image4 = UIImage(named: "4_kat")
    let image5 = UIImage(named: "5_kat")
    let image6 = UIImage(named: "6_kat")
    var tapView = UITapGestureRecognizer()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Котики"
        createImageView(myImageView: myImageView1, image:image1!, x: Int(view.bounds.width)/2 - 160, y: 80)
        createImageView(myImageView: myImageView2, image:image2!, x: Int(view.bounds.width)/2 + 10, y: 80)
        createImageView(myImageView: myImageView3, image:image3!, x: Int(view.bounds.width)/2 - 160, y: 220)
        createImageView(myImageView: myImageView4, image:image4!, x: Int(view.bounds.width)/2 + 10, y: 220)
        createImageView(myImageView: myImageView5, image:image5!, x: Int(view.bounds.width)/2 - 160, y: 360)
        createImageView(myImageView: myImageView6, image:image6!, x: Int(view.bounds.width)/2 + 10, y: 360)
    }
    
    //MARK: - Functions
    //createImageView
    func createImageView(myImageView: UIImageView, image:UIImage, x:Int, y:Int) {
        let frame = CGRect(x: x, y: y, width: 150, height: 120)
        myImageView.image = image
        myImageView.frame = frame
        myImageView.layer.borderWidth = 2
        myImageView.layer.cornerRadius = 8
        myImageView.layer.borderColor = UIColor.black.cgColor
        myImageView.contentMode = .scaleAspectFill
        myImageView.clipsToBounds = true
        myImageView.addGestureRecognizer(forTap())
        myImageView.isUserInteractionEnabled = true
        view.addSubview(myImageView)
        
    }
    //Функция касания
    func forTap() -> UITapGestureRecognizer {
        let tap = UITapGestureRecognizer(target: self, action: #selector(myImageTapped(recognizer:)))
        return tap
    }
    //Функция перехода на второй вью
    @objc func myImageTapped(recognizer:UITapGestureRecognizer) {
        let secondVC = SecondViewController()
        selectedImage = recognizer.view as? UIImageView
        secondVC.myImageView.image = selectedImage?.image
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
}

