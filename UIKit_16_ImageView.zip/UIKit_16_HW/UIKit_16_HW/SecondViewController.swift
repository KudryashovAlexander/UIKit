//
//  SecondViewController.swift
//  UIKit_16_HW

import UIKit

class SecondViewController: UIViewController {
    
    var myImageView = UIImageView()
    var contentMode = ["scaleToFill","scaleAspectFit","scaleAspectFill","redraw","center","top","bottom","left","right","topLeft","topRight","bottomLeft"]
    var pickerContentMode = UIPickerView()
    let alphaSlider = UISlider()

    override func viewDidLoad() {
        super.viewDidLoad()
        createImageView()
        createPickerView()
        pickerContentMode.delegate = self
        createAlphaSlider()
    }
    
    //MARK: - Create View Elements
    func createImageView() {
        let frame = CGRect(x: 20, y: 80, width: Int(view.bounds.width) - 40, height: Int(view.bounds.height/2) - 80)
        myImageView.frame = frame
        myImageView.contentMode = .scaleAspectFit
        view.addSubview(myImageView)
    }
    func createPickerView() {
        let frame = CGRect(x: 0, y: Int(view.bounds.height/2) + 10, width: Int(view.bounds.width), height: Int(view.bounds.height/3))
        pickerContentMode.frame = frame
        view.addSubview(pickerContentMode)
    }
    func createAlphaSlider() {
        let frame = CGRect(x: 20, y: Int(view.bounds.height) - 100, width: Int(view.bounds.width) - 40, height: 30)
        alphaSlider.frame = frame
        alphaSlider.addTarget(self, action: #selector(changedAlpha(sender:)), for: .valueChanged)

        view.addSubview(alphaSlider)
    }
    
    @objc func changedAlpha(sender: UISlider) {
        if sender == alphaSlider {
            let currentValue = CGFloat(sender.value)
            myImageView.alpha =  (1 - currentValue)
        }
        
    }

}
//MARK: - UIPickerViewDataSourse
extension SecondViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       return contentMode.count
    }
}

//MARK: - UIPickerViewDelegate
extension SecondViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return contentMode[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if let mode = UIView.ContentMode(rawValue: row) {
            myImageView.contentMode = mode
        }
    }
}

