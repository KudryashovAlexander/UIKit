//
//  ViewController.swift
//  UIKit_4_HW
//
//  Created by Александр Кудряшов on 27.01.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    //MARK: - Создание элементов
    var labelZero = UILabel()
    var labelOne = UILabel()
    var labelTwo = UILabel()
    var labelTree = UILabel()
    var labelFor = UILabel()
    var labelFive = UILabel()
    var labelSix = UILabel()
    
    @IBOutlet weak var myButton: UIButton!
    
    var textFieldOne = UITextField()
    var textFieldTwo = UITextField()
    var textFieldTree = UITextField()
    var textFieldFor = UITextField()
    
    var mySwitchFive = UISwitch()
    var mySwitchSix = UISwitch()
    

    //MARK: - Alert
    func alert1() {
        let alertController = UIAlertController(title: "Введите данные", message: "Введите численное значение во все поля", preferredStyle: .alert)
        let action = UIAlertAction(title: "Внесу", style: .default) { (action) in

        }
        alertController.addAction(action)
        self.present (alertController, animated: true, completion: nil)
    }
    
    //Функция учета Switch
    func checkSwitch() -> Double {
        switch (self.mySwitchFive.isOn,self.mySwitchSix.isOn) {
        case (true,true):
            return -1.3
        case (true,false):
            return -0.3
        case (false,true):
            return -1.0
        default:
            return 0
        }
    }
    
    //Функция расчета значения и проверки на значение
    func calculate() -> Double {
    var result = 0.0
        if let x1 = Double(textFieldOne.text!) {
            if let x2 = Double(textFieldTwo.text!) {
                if let x3 = Double(textFieldTree.text!){
                    if let x4 = Double(textFieldFor.text!){
                         result = ((x1 - x2) + (x1 - x2) * x3 * (x4 + checkSwitch()) / 100) / (12 * x3)
                    } else { alert1() }
                } else { alert1() }
            } else { alert1() }
        } else { alert1() }
        return result
    }
    

    //MARK: - Lifesyle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Наполнение текстом
        labelZero.text = "Расчет ипотеки"
        self.labelZero.textAlignment = .center
        labelOne.text = "Сумма ипотеки(руб.)"
        self.labelOne.textAlignment = .left
        labelTwo.text = "Первоначальный взнос(руб.)"
        self.labelTwo.textAlignment = .left
        labelTree.text = "Срок ипотеки (лет)"
        self.labelTree.textAlignment = .left
        labelFor.text = "Процентная ставка(%)"
        self.labelFor.textAlignment = .left
        
        labelFive.text = "Подтверждение дохода(-0.3%)"
        self.labelFive.textAlignment = .left
        labelSix.text = "Страхование жизни(-1%)"
        self.labelSix.textAlignment = .left
        
        myButton.setTitle("Расчитать", for: .normal )
        myButton.backgroundColor = .green
        
        
        

        //Размещение текстов в сториборд
        self.labelZero.frame = CGRect(x: 100, y: 100, width: 250, height: 20)
        self.labelZero.center.x = self.view.center.x
    
        self.labelOne.frame = CGRect(x: 30, y: 160, width: 250, height: 20)
        self.labelTwo.frame = CGRect(x: 30, y: 200, width: 250, height: 20)
        self.labelTree.frame = CGRect(x: 30, y: 240, width: 250, height: 20)
        self.labelFor.frame = CGRect(x: 30, y: 280, width: 250, height: 20)
        self.labelFive.frame = CGRect(x: 30, y: 330, width: 250, height: 20)
        self.labelSix.frame = CGRect(x: 30, y: 380, width: 250, height: 20)
        
        self.textFieldOne.frame = CGRect(x: 320, y: 160, width: 80, height: 20)
        self.textFieldOne.borderStyle = .roundedRect
        self.textFieldTwo.frame = CGRect(x: 320, y: 200, width: 80, height: 20)
        self.textFieldTwo.borderStyle = .roundedRect
        self.textFieldTree.frame = CGRect(x: 320, y: 240, width: 80, height: 20)
        self.textFieldTree.borderStyle = .roundedRect
        self.textFieldFor.frame = CGRect(x: 320, y: 280, width: 80, height: 20)
        self.textFieldFor.borderStyle = .roundedRect
        
        
        self.mySwitchFive.frame = CGRect(x: 320, y: 325, width: 0, height: 0)
        self.mySwitchSix.frame = CGRect(x: 320, y: 375, width: 0, height: 0)
        
        self.myButton.frame = CGRect(x: 100, y: 500, width: 150, height: 40)
        self.myButton.center.x = self.view.center.x
        

        //Показать в сториборд
        self.view.addSubview(labelZero)
        self.view.addSubview(labelOne)
        self.view.addSubview(labelTwo)
        self.view.addSubview(labelTree)
        self.view.addSubview(labelFor)
        self.view.addSubview(labelFive)
        self.view.addSubview(labelSix)
        
        self.view.addSubview(textFieldOne)
        self.view.addSubview(textFieldTwo)
        self.view.addSubview(textFieldTree)
        self.view.addSubview(textFieldFor)
        
        self.view.addSubview(mySwitchFive)
        self.view.addSubview(mySwitchSix)
        
        self.view.addSubview(myButton)
    }
    //Функция передачи значения во второй вью
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? SecondViewController {
        destinationVC.labelResult.text = String(self.calculate())
        }
    }

}

