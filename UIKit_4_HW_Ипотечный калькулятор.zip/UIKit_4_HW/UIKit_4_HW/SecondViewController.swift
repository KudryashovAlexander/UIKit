//
//  SecondViewController.swift
//  UIKit_4_HW
//
//  Created by Александр Кудряшов on 29.01.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    
    //Создадим кнопку для обратного перехода в первый вью и текстовые строки
    var buttonBack = UIButton()
    var labelResultText = UILabel()
    var labelResult = UILabel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        //Размещаем кнопку во вью
        self.buttonBack.setTitle("Назад", for: .normal)
        self.buttonBack.frame = CGRect(x: 100, y: 400, width: 100, height: 30)
        self.buttonBack.center.x = view.center.x
        self.buttonBack.backgroundColor = .red
        
        //Рамещаем текстовые строки
        self.labelResultText.text = "Ежемесячный платеж"
        self.labelResultText.frame = CGRect(x: 100, y: 200, width: 300, height: 30)
        self.labelResultText.textAlignment = .center
        self.labelResultText.center.x = view.center.x
        
        self.labelResult.frame = CGRect(x: 100, y: 300, width: 100, height: 30)
        self.labelResult.textAlignment = .center
        self.labelResult.center.x = view.center.x
       
       
        
        // Покажем кнопку и текст
        self.view.addSubview(buttonBack)
        self.view.addSubview(labelResultText)
        self.view.addSubview(labelResult)
        
        
        
        //Переход на пторой вью
        buttonBack.addTarget(self, action: #selector (transition(target:)), for: .touchUpInside)

    }
    @objc func transition(target: UIButton) {
        dismiss(animated: true, completion: nil)
        labelResult.text = "0"
    }
    
    

}
