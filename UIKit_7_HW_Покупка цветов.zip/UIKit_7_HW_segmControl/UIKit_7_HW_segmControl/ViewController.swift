//
//  ViewController.swift
//  UIKit_7_HW_segmControl
//
//  Created by Александр Кудряшов on 13.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var labelOne = UILabel()
    var segmentControl = UISegmentedControl()
    var imageView = UIImageView()
    var labelName = UILabel()
    var labelPrice = UILabel()
    var labelPackaging = UILabel()
    var switchPacking = UISwitch()
    var labelDelivery = UILabel()
    var switchDelivery = UISwitch()
    var buttonPay = UIButton()
    
    var segmentArray = ["№1", "№2", "№3", "№4", "№5"]
    var priceArray = [1000, 1500, 2400, 3600, 2200]
    var imageArray = [ UIImage(named: "flavour_1.jpg"),
                       UIImage(named: "flavour_2.jpg"),
                       UIImage(named: "flavour_3.jpg"),
                       UIImage(named: "flavour_4.jpg"),
                       UIImage(named: "flavour_5.jpg") ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Размещаем на экране
        // - labelOne
        labelOne.frame = CGRect(x: (view.center.x - 150), y: 60, width: 300, height: 20)
        labelOne.text = "Выберите букет"
        labelOne.textAlignment = .center
        self.view.addSubview(labelOne)
        
        // - segmentControl
        segmentControl = UISegmentedControl(items: segmentArray)
        segmentControl.frame = CGRect(x: (view.center.x - 150), y: 100, width: 300, height: 20)
        segmentControl.selectedSegmentIndex = 0
        self.view.addSubview(segmentControl)
        segmentControl.addTarget(self, action: #selector(changeFlower(target:)), for: .valueChanged)
        
        // - imageView
        imageView.frame = CGRect(x: (view.center.x - 125), y: 140, width: 250, height: 250)
        imageView.image = imageArray[0]
        self.view.addSubview(imageView)
        
        // - labelName
        labelName.frame = CGRect(x: (view.center.x - 150), y: 400, width: 300, height: 20)
        labelName.text = "Букет номер " + String(segmentArray[segmentControl.selectedSegmentIndex])
        labelName.textAlignment = .center
        self.view.addSubview(labelName)
        
        // - labelPrice
        labelPrice.frame = CGRect(x: (view.center.x - 150), y: 440, width: 300, height: 20)
        labelPrice.text = "Цена " + String(priceArray[segmentControl.selectedSegmentIndex])
        labelPrice.textAlignment = .center
        self.view.addSubview(labelPrice)
        
        
        // - labelPackaging
        labelPackaging.frame = CGRect(x: 40, y: 480, width: 200, height: 20)
        labelPackaging.text = "Упаковка +300Р"
        self.view.addSubview(labelPackaging)
        
        // - switchPacking
        switchPacking.frame = CGRect(x: 320, y: 480, width: 0, height: 0)
        switchPacking.addTarget(self, action: #selector(changeTextButton), for: .valueChanged)
        self.view.addSubview(switchPacking)
        
        
        // - labelDelivery
        labelDelivery.frame = CGRect(x: 40, y: 520, width: 200, height: 20)
        labelDelivery.text = "Доставка +400Р"
        self.view.addSubview(labelDelivery)
    
        // - switchDelivery
        switchDelivery.frame = CGRect(x: 320, y: 520, width: 0, height: 0)
        switchDelivery.addTarget(self, action: #selector(changeTextButton), for: .valueChanged)
        self.view.addSubview(switchDelivery)
        
        // - UIButton
        buttonPay.frame = CGRect(x: (view.center.x - 100), y: 600, width: 200, height: 30)
        buttonPay.setTitle("Купить за \(totalCost())руб.", for: .normal)
        buttonPay.backgroundColor = UIColor.purple
        buttonPay.addTarget(self, action: #selector(payFlower(sender:)), for: .touchDown)
        self.view.addSubview(buttonPay)
 
    }
    //Функция выбора значения
    @objc func changeFlower (target: UISegmentedControl) {
        if target == segmentControl {
            let segmentIndex = target.selectedSegmentIndex
            self.imageView.image = self.imageArray[segmentIndex]
            
            //Значение
            let value = target.titleForSegment(at: segmentIndex)
//            print(value ?? "")
            labelName.text = "Букет номер " + (value ?? "")
            labelPrice.text = "Цена " + String(priceArray[segmentIndex])
        }
        //Обновляем текст в кнопке
        changeTextButton()
    }
    
   //Функуия подсчета значений допов
    func paymentDop() -> Int {
        switch (switchPacking.isOn,switchDelivery.isOn){
        case(true,true):
            return 700
        case(false,true):
            return 400
        case(true,false):
            return 300
        default:
            return 0
        }
        
    }
    
    //Функция подсчета итоговой стоимости
    func totalCost() -> Int {
        let segmentPrice = priceArray[segmentControl.selectedSegmentIndex]
        return segmentPrice + paymentDop()
    }

    
    //Функция изменения текста в кнопке
    @objc func changeTextButton() {
        buttonPay.setTitle("Купить за \(totalCost())руб.", for: .normal)
    }
    
    //Функция нажатия кнопки
    @objc func payFlower(sender: UIButton){
        let destination = SecondVC()
        present(destination,animated: true, completion: nil)
        
    }


}

