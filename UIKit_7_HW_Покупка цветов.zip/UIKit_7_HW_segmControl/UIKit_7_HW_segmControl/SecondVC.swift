//
//  SecondVC.swift
//  UIKit_7_HW_segmControl
//
//  Created by Александр Кудряшов on 13.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
    var labelOk = UILabel()
    var imageView = UIImageView()
    var buttonBack = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        //окрашиваем view в белый
        view.backgroundColor = UIColor.white
        
        
        //Размещаем
        // - labelOk
        labelOk.text = "Ваш заказ принят"
        labelOk.frame = CGRect(x: (view.center.x - 100), y: 150, width: 200, height: 20)
        labelOk.textAlignment = .center
        self.view.addSubview(labelOk)
        
        // - imageView
        imageView.image = UIImage(named: "OK.png")
        imageView.frame = CGRect(x: (view.center.x - 40), y: 300, width: 80, height: 80)
        self.view.addSubview(imageView)
        
        // - buttonBack
        buttonBack.frame = CGRect(x: (view.center.x - 100), y: 600, width: 200, height: 30)
        buttonBack.setTitle("<Back", for: .normal)
        buttonBack.backgroundColor = UIColor.purple
        buttonBack.addTarget(self, action:  #selector(back(sender:)), for: .touchDown)
        self.view.addSubview(buttonBack)

       
    }
    // Функция возврата на первый экран
    @objc func back(sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
}
