//
//  SecondVC.swift
//  UIKit_11_HW_UITabbarcontroller
//
//  Created by Александр Кудряшов on 27.03.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
    var textView = UITextView()

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Инградиенты"
        title = navigationItem.title
        view.backgroundColor = .white

        
        text()

    }
    //Размещение текста инструкции
    func text() {
        textView.text = "Мясо для бульона  — 400-450 Грамм (говядина, свинина, курица) Картофель  — 4 Штуки Луковица  — 1 Штука Морковь  — 1 Штука Свекла  — 1 Штука Капуста  — 1/3-1/2 Штуки Чеснок  — 2-3 Зубчиков Томатная паста  — 2 Ст. ложки Уксус  — 1 Ст. ложка Соль, перец, растительное масло  — По вкусу"
        textView.frame = CGRect(x: 0, y: 200, width: UIScreen.main.bounds.width - 80, height: 180)
        textView.center.x = view.center.x
        textView.font = UIFont(name: "Arial", size: 17)
        self.view.addSubview(textView)
        
    }

    

}
