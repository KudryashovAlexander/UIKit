//
//  StartVC.swift
//  UIKit_11_HW_UITabbarcontroller
//
//  Created by Александр Кудряшов on 30.03.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class StartVC: UIViewController {
    
    
    var label = UILabel()
    var imageView = UIImageView()
    var startButton = UIButton()

    override func viewDidLoad() {
        self.view.backgroundColor = .white

        super.viewDidLoad()
        labelText()
        createImage()
        createNextButton()

        
        
        
        
    }
    //Размещение текста
    func labelText() {
        label.frame = CGRect(x: (view.center.x - 100), y: 100, width: UIScreen.main.bounds.width - 80, height: 30)
        label.text = "Это пошаговая инструкция рецепта борща"
        label.textAlignment = .center
        self.view.addSubview(label)
    }
    
    
    //Размещение картинки
    func createImage() {
        let image = UIImage(named: "borsch.jpeg")
        imageView = UIImageView(image: image)
        imageView.frame = CGRect(x: 0, y: 110, width: UIScreen.main.bounds.width - 80, height: 300)
        imageView.center.x = view.center.x
        imageView.contentMode = .scaleAspectFit
        self.view.addSubview(imageView)
    }
    
    
    
    //Размещение кнопки старта
    func createNextButton() {
        startButton.frame = CGRect(x: 0, y: 600, width: 140, height: 30)
        startButton.setTitle("Начать готовить", for: .normal)
        startButton.backgroundColor = UIColor.blue
        self.view.addSubview(startButton)
        //Функция нажатия кнопки вперед
        //startButton.addTarget(self, action: #selector(next(sender:)), for: .touchUpInside)
        self.view.addSubview(startButton)
        
    }

    
    
    
    
    
}
