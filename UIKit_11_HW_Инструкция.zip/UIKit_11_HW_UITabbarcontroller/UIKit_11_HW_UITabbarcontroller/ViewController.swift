//
//  ViewController.swift
//  UIKit_11_HW_UITabbarcontroller
//
//  Created by Александр Кудряшов on 27.03.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var textStep = UILabel()
    var buttonBack = UIButton()
    var buttonNext = UIButton()
    var imageStep = UIImageView()
    var textInstuction = UITextView()
    var step:Int = 1 {
        didSet {
            switch step {
            case 1:
                buttonBack.isHidden = true
                buttonNext.isHidden = false
            case textArray.count:
                buttonBack.isHidden = false
                buttonNext.isHidden = true
            default:
                buttonBack.isHidden = false
                buttonNext.isHidden = false
            }
        }
    }
    
    var textArray:[String] = ["1. Вот необходимый нам набор ингредиентов.",
                              "2. Для начала необходимо сварить бульон. Мясо вымойте, выложите в кастрюлю и залейте водой. После закипания уберите огонь до минимума и варите до мягкости мяса (время зависит от того, какое именно мясо вы выбрали). Аккуратно достаньте его из бульона после готовности.",
                              "3. Бульон при желании процедите. Подсолите по вкусу и выложите нарезанный кубиками картофель. Варите около 10-12 минут.",
                              "4. Лук с морковью очистите, измельчите и обжарьте на сковороде с небольшим количеством растительного масла.",
                              "5. В кастрюлю с бульоном выложите обжаренные овощи и мелко нашинкованную капусту.",
                              "6. На сковороду тем временем налейте еще немного масла и выложите тертую свеклу. Обжарьте пару минут и добавьте уксус. Тушите еще минут 5, а после выложите томатную пасту. Томите на медленном огне еще 5-7 минут.",
                              "7. В бульон выложите мясо, предварительно нарезав его порционными кусочками, и свеклу.",
                              "8. По вкусу добавьте соль, перец, сахар и чеснок. Варите еще минут 7-10 до готовности картофеля. После снимите с огня, накройте крышкой и оставьте на полчасика настояться. Перед подачей можно добавить зелень и сметану. Приятного аппетита!"]
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = "Инструкция"
        view.backgroundColor = .white

        title = navigationItem.title
        step = 1
        
        //Размещение на экране
        numberStep()
        createImage()
        textInstruction()
        createBackButton()
        createNextButton()
        
    }
    
    //Размещение номера шага
    func numberStep() {
        textStep.frame = CGRect(x: (view.center.x - 100), y: 100, width: 200, height: 30)
        textStep.text = "Шаг " + String(step) + " из \(String(textArray.count)) "
        textStep.textAlignment = .center
        self.view.addSubview(textStep)
    }
    //Размещение картинки
    func createImage() {
        let image = UIImage(named: (String(step) + ".jpeg"))
        imageStep = UIImageView(image: image)
        imageStep.frame = CGRect(x: 0, y: 110, width: UIScreen.main.bounds.width - 80, height: 300)
        imageStep.center.x = view.center.x
        imageStep.contentMode = .scaleAspectFit
        self.view.addSubview(imageStep)
    }
    
    //Размещение текста инструкции
    func textInstruction() {
        let text = textArray[step - 1]
        textInstuction.text = text
        textInstuction.frame = CGRect(x: 0, y: 380, width: UIScreen.main.bounds.width - 80, height: 180)
        textInstuction.center.x = view.center.x
        textInstuction.font = UIFont(name: "Arial", size: 17)
        self.view.addSubview(textInstuction)
  
    }
    
    //Функция генерации кнопки назад
    func createBackButton() {
        buttonBack.frame = CGRect(x: view.center.x - 150, y: 600, width: 140, height: 30)
        buttonBack.setTitle("<Шаг назад", for: .normal)
        buttonBack.backgroundColor = UIColor.blue
        //Функция нажатия кнопки назад
        buttonBack.addTarget(self, action: #selector(back(sender:)), for: .touchUpInside)
        self.view.addSubview(buttonBack)
        
    }
    
    //Функция генерации кнопки вперед
    func createNextButton() {
        buttonNext.frame = CGRect(x: view.center.x + 10, y: 600, width: 140, height: 30)
        buttonNext.setTitle("Шаг вперед>", for: .normal)
        buttonNext.backgroundColor = UIColor.blue
        self.view.addSubview(buttonNext)
        //Функция нажатия кнопки вперед
        buttonNext.addTarget(self, action: #selector(next(sender:)), for: .touchUpInside)
    }

    //Функция нажатия кнопки назад
    @objc func back(sender:UIButton) {
        if step > 1 {
            step -= 1
            changeImageAndText()
        }
  
    }
    //Функция нажатия кнопки назад
    @objc func next(sender:UIButton) {
        if step < 8{
            step += 1
            changeImageAndText()
        }
    }
    
    //Функция изменения инструкции
    func changeImageAndText() {
        textStep.text = "Шаг " + String(step) + " из \(String(textArray.count))"
        
        let image = UIImage(named: (String(step) + ".jpeg"))
        imageStep.image = image
        
        let text = textArray[step - 1]
        textInstuction.text = text

    }


}

