//
//  ThirdVC.swift
//  UIKit_11_HW_UITabbarcontroller
//
//  Created by Александр Кудряшов on 27.03.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ThirdVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Third"
        view.backgroundColor = .blue
        
    }
    


}
