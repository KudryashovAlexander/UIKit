//
//  SecondVC.swift
//  UIKit_6_HW_UIslider
//
//  Created by Александр Кудряшов on 10.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
    
     //MARK: - Elements of View
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var buttonSave: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var nikTextField: UITextField!
    @IBOutlet weak var sexPicker: UIPickerView!
    @IBOutlet weak var colorSlider: UISlider!
    let array:[String] = ["not selected", "Men", "Women"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sexPicker.dataSource = self
        sexPicker.delegate = self
    }
    
    //MARK: - Methods
    //Back
    @IBAction func buttonBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    //Save
    @IBAction func buttonSave(_ sender: Any) {
        let tc = storyboard?.instantiateViewController(withIdentifier: "thirdViewController")
        self.present (tc!,animated:true, completion: nil)
    }
    
    @IBAction func colorSlider(_ sender: UISlider) {
        switch colorSlider.value {
        case 0.0..<0.071: view.backgroundColor = UIColor.white
        case 0.071..<0.142: view.backgroundColor = UIColor.darkGray
        case 0.142..<0.213: view.backgroundColor = UIColor.lightGray
        case 0.213..<0.284: view.backgroundColor = UIColor.gray
        case 0.284..<0.355: view.backgroundColor = UIColor.red
        case 0.355..<0.426: view.backgroundColor = UIColor.green
        case 0.426..<0.497: view.backgroundColor = UIColor.blue
        case 0.497..<0.568: view.backgroundColor = UIColor.cyan
        case 0.568..<0.639: view.backgroundColor = UIColor.yellow
        case 0.639..<0.71: view.backgroundColor = UIColor.magenta
        case 0.71..<0.781: view.backgroundColor = UIColor.orange
        case 0.781..<0.852: view.backgroundColor = UIColor.purple
        case 0.852..<0.923: view.backgroundColor = UIColor.brown
        case 0.923...1.0: view.backgroundColor = UIColor.clear
        default:
            view.backgroundColor = UIColor.white
        }
    }

    
    //функция alert
    func alert() {
        let alertController = UIAlertController(title: "Внимание", message: "Не заполнены поля!", preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "ОК", style: .default) { (action) in }
        alertController.addAction(alertAction)
        self.present(alertController, animated:true, completion:nil)
    }
    //Функция проверки корректности введенных данных
    func chek() -> Bool {
        if (nameTextField.text?.count == 0 && nikTextField.text?.count == 0) {
            return false
        } else { return true }
    }
}

//Picker
extension SecondVC: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 3
    }
}

extension SecondVC:UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.array[row]
    }
}
