//
//  ThirdVC.swift
//  UIKit_6_HW_UIslider
//
//  Created by Александр Кудряшов on 10.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ThirdVC: UIViewController {

    @IBOutlet weak var buttonBack: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func buttonBack(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
}
