//
//  ViewController.swift
//  UIKit_6_HW_UIslider
//
//  Created by Александр Кудряшов on 07.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK: - Elements of View
    var labelLogin = UILabel()
    var labelMail = UILabel()
    var mailTextField = UITextField()
    var labelPassword = UILabel()
    var passwordTextField = UITextField()
    @IBOutlet weak var myButton: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Наполняем переменные
        //labelLogin
        labelLogin.text = "Логин"
        labelLogin.font = UIFont(name: "Arial", size: 25)
        labelLogin.textAlignment = .center
        labelLogin.frame = CGRect(x: 0, y: 100, width: 200, height: 50)
        labelLogin.center.x = view.center.x
        
        //labelMail
        labelMail.text = "Введите вашу почту"
        labelMail.frame = CGRect(x: 0, y: 180, width: 300, height: 20)
        labelMail.center.x = view.center.x
        
        //mailTextField
        mailTextField.borderStyle = .roundedRect
        mailTextField.frame = CGRect(x: 0, y: 210, width: 300, height: 30)
        mailTextField.center.x = view.center.x
        
        //labelPassword
        labelPassword.text = "Введите ваш пароль"
        labelPassword.frame = CGRect(x: 0, y: 250, width: 300, height: 20)
        labelPassword.center.x = view.center.x
        
        //passwordTextField
        passwordTextField.borderStyle = .roundedRect
        passwordTextField.frame = CGRect(x: 0, y: 280, width: 300, height: 30)
        passwordTextField.center.x = view.center.x
        passwordTextField.isSecureTextEntry = true
        
        //myButton
        myButton.setTitle("Войти", for: .normal)
        myButton.setTitleColor(UIColor.white, for: .normal)
        myButton.frame = CGRect(x: 0, y: 350, width: 180, height: 30)
        myButton.center.x = view.center.x
        myButton.backgroundColor = UIColor.blue
        
        //Добавляем в поле вью
        view.addSubview(labelLogin)
        view.addSubview(labelMail)
        view.addSubview(mailTextField)
        view.addSubview(labelPassword)
        view.addSubview(passwordTextField)
    }

    //MARK: - Methods
    @IBAction func myButton(_ sender: UIButton) {
        if chek() {
           let vc = storyboard?.instantiateViewController(withIdentifier: "secondViewController")
            self.present (vc!,animated:true, completion: nil)
        } else {
            alert()
        }
    }
    
    //Функция проверки корректности введенных данных
    func chek() -> Bool {
        if (mailTextField.text?.count == 0 && passwordTextField.text?.count == 0) {
            return false
        } else { return true }
    }
     //функция alert
    func alert() {
        let alertController = UIAlertController(title: "Внимание", message: "Не заполнены поля!", preferredStyle: .alert)
        let alertAction = UIAlertAction(title: "ОК", style: .default) { (action) in }
        alertController.addAction(alertAction)
        self.present(alertController, animated:true, completion:nil)
    }
    
}

