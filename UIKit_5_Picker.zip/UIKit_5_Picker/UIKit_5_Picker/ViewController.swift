//
//  ViewController.swift
//  UIKit_5_Picker
//
//  Created by Александр Кудряшов on 02.02.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let picker = UIDatePicker()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.center = view.center
        picker.datePickerMode = .countDownTimer
        
        self.view.addSubview(picker)
        
        var oneYearTime = TimeInterval()
        oneYearTime = 365 * 24 * 60 * 60
        
        let todayDate = Date()
        let oneYearFromToday = todayDate.addingTimeInterval(oneYearTime)
        let twoYearFromDate = todayDate.addingTimeInterval(2 * oneYearTime)
        
        picker.minimumDate = oneYearFromToday
        picker.maximumDate = twoYearFromDate
        
        picker.countDownDuration = 2 * 60
        
        // Для наблюдения за пикером и забор информации у него
        picker.addTarget(self, action: #selector(datePickerChange(paramdatePicker:)), for: .valueChanged)

    }
    @objc func datePickerChange(paramdatePicker:UIDatePicker) {
        
        if paramdatePicker.isEqual(self.picker) {
            print("dateChange : = ", paramdatePicker.date)
        }
    }
}
