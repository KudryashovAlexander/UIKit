
//  ViewController.swift
//  UIKit_14_HW


import UIKit

class ViewController: UIViewController {
    //MARK: - Elements
    var myTextView = UITextView()
    var currentFont = Data.fontArray[0]
    var textSize = 14
    var sliderFontSize = UISlider()
    var buttonTextColorBlack = UIButton()
    var buttonTextColorGreen = UIButton()
    var buttonTextColorBlue = UIButton()
    var buttonTextColorPurple = UIButton()
    var switchNightMode = UISwitch()
    var buttonFontThicknessSmall = UIButton()
    var buttonFontThicknessBig = UIButton()
    var pickerFont = UIPickerView()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        createMyTextView()
        createSliderFontSize()
        createTextColor(button: buttonTextColorBlack, color: .black, x: 20)
        createTextColor(button: buttonTextColorGreen, color: .green, x: 55)
        createTextColor(button: buttonTextColorBlue, color: .blue, x: 90)
        createTextColor(button: buttonTextColorPurple, color: .purple, x: 125)
        createSwitchNightMode()
        createButtonFontThicknessSmall()
        createButtonFontThicknessBig()
        createPickerFont()
        self.pickerFont.dataSource = self
        self.pickerFont.delegate = self
    }

    //MARK: - Function for view
    //create myTextView
    func createMyTextView() {
        let frame = CGRect(x: 20, y: 50, width: view.bounds.width - 40, height: 250)
        myTextView.frame = frame
        myTextView.backgroundColor = view.backgroundColor
        myTextView.textColor = UIColor.black
        myTextView.text = Data.text
        myTextView.isEditable = false
        myTextView.font = UIFont(name: currentFont, size: CGFloat(textSize))
        view.addSubview(myTextView)
    }
    //create sliderFontSize
    func createSliderFontSize() {
        let frame = CGRect(x: 20 , y: 330, width: view.bounds.width - 40, height: 30)
        sliderFontSize.frame = frame
        sliderFontSize.minimumValue = 14
        sliderFontSize.maximumValue = 76
        sliderFontSize.addTarget(self, action: #selector(changeSlider(sender:)), for: .valueChanged)
        view.addSubview(sliderFontSize)
    }
    @objc func changeSlider(sender: UISlider){
        if sender == sliderFontSize {
            textSize = Int(sender.value)
            let valueSender = CGFloat(textSize)
            myTextView.font = UIFont(name: currentFont, size: valueSender)
        } else {
            print("Error change slider")
        }
    }
    
    //create buttonTextColor
    func createTextColor(button:UIButton, color: UIColor, x: Int) {
        let frame = CGRect(x: x, y: 380, width: 30, height: 30)
        button.frame = frame
        button.backgroundColor = color
        button.layer.cornerRadius = 5    // радиус закругления закругление
        button.layer.borderWidth = 2.0   // толщина обводки
        button.layer.borderColor = (UIColor(red: 242.0/255.0, green: 116.0/255.0, blue: 119.0/255.0, alpha: 1.0)).cgColor // цвет обводки
        button.clipsToBounds = true
        button.addTarget(self, action: #selector(color(sender:)), for: .touchDown)
        view.addSubview(button)
    }
    @objc func color(sender:UIButton) {
        if let color = sender.backgroundColor {
            myTextView.textColor = color
        } else {
            print("Error color")
        }
    }
    
    //create switchNightMode
    func createSwitchNightMode() {
        let frame = CGRect(x: 180, y: 380, width: 0, height: 0)
        switchNightMode.frame = frame
        switchNightMode.addTarget(self, action: #selector(switchNight), for: .valueChanged)
        view.addSubview(switchNightMode)
    }
    @objc func switchNight(sender:UISwitch) {
        if sender.isOn {
            let color = UIColor.gray
            myTextView.backgroundColor = color
            view.backgroundColor = color
        } else {
            let color = UIColor.white
            myTextView.backgroundColor = color
            view.backgroundColor = color
        }
    }
    //create ButtonFontThicknessSmall
    func createButtonFontThicknessSmall() {
        let frame = CGRect(x: 250, y: 380, width: 30, height: 30)
        buttonFontThicknessSmall.frame = frame
        buttonFontThicknessSmall.setTitle("aa", for: .normal)
        buttonFontThicknessSmall.setTitleColor(.black, for: .normal)
        buttonFontThicknessSmall.contentMode = .center
        buttonFontThicknessSmall.layer.cornerRadius = 5    // радиус закругления закругление
        buttonFontThicknessSmall.layer.borderWidth = 2.0   // толщина обводки
        buttonFontThicknessSmall.layer.borderColor = (UIColor(red: 242.0/255.0, green: 116.0/255.0, blue: 119.0/255.0, alpha: 1.0)).cgColor // цвет обводки
        buttonFontThicknessSmall.clipsToBounds = true
        buttonFontThicknessSmall.addTarget(self, action: #selector(small(sender:)), for: .touchDown)
        view.addSubview(buttonFontThicknessSmall)
    }
    @objc func small(sender:UIButton) {
        
        myTextView.text = Data.text.lowercased()
    }
    //create ButtonFontThicknessBig()
    func createButtonFontThicknessBig() {
        let frame = CGRect(x: 285, y: 380, width: 30, height: 30)
        buttonFontThicknessBig.frame = frame
        buttonFontThicknessBig.setTitle("AA", for: .normal)
        buttonFontThicknessBig.setTitleColor(.black, for: .normal)
        buttonFontThicknessBig.contentMode = .center
        buttonFontThicknessBig.layer.cornerRadius = 5    // радиус закругления закругление
        buttonFontThicknessBig.layer.borderWidth = 2.0   // толщина обводки
        buttonFontThicknessBig.layer.borderColor = (UIColor(red: 242.0/255.0, green: 116.0/255.0, blue: 119.0/255.0, alpha: 1.0)).cgColor // цвет обводки
        buttonFontThicknessBig.clipsToBounds = true
        buttonFontThicknessBig.addTarget(self, action: #selector(big(sender:)), for: .touchDown)
        view.addSubview(buttonFontThicknessBig)
    }
    @objc func big(sender:UIButton) {
       myTextView.text = Data.text.uppercased()
    }
    
    //create pickerFont
    func createPickerFont() {
        let frame = CGRect(x: 0, y: (UIScreen.main.bounds.height/3)*2, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height/3)
        pickerFont.frame = frame
        view.addSubview(pickerFont)
    }
}

//MARK: - UIPickerViewDataSource
extension ViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Data.fontArray.count
    }
 
}
//MARK: - UIPickerViewDelegate
extension ViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let text = Data.fontArray[row]
        return text
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerFont {
                myTextView.font = UIFont.init(name: Data.fontArray[row], size: CGFloat(textSize))
                currentFont = Data.fontArray[row]
        }
    }
}
