//
//  ViewController.swift
//  UIKit_13_HW
//
//  Created by Александр Кудряшов on 01.04.2019.
//  Copyright © 2019 Александр Кудряшов. All rights reserved.
//

/*
 Задание
 1) Повторить что было в уроке
 2) Создать форму регистрации, 3-4 TextField, при заполнение первого TeхtField, по нажатию на "Ввод" переходит к заполнению второго TextField и тд, на последнем по нажатию на "Ввод" клавиатура убирается.
 3) Через NotificationCentr подписаться на выезд клавиатуры и двигать контент вверх при выезде клавиатуры, и вниз при скрытие.
 4) После окна регистрации сделать мини приложение на свой вкус, затронув максимальное количество UI элементов.
 5) Придумать обход регистрации если пользователь уже существует
 */

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    

    var regitrationSegmentController = UISegmentedControl()
    
    //Окно входа
    var loginNameTextField = UITextField()
    var passwordTextField = UITextField()
    var signButton = UIButton()
    
//    //Окно регистрации
//    var nameTextField = UITextField()
//    var surnameTextField = UITextField()
//    var mailTextField = UITextField()
//    var telephoneTextField = UITextField()
//    var regitrationButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        segmentControlView()
        loginNameView()
        passwordView()
        buttonView()
        
        self.hideKeyboard()
        
        //Передвигает экран вверх
        NotificationCenter.default.addObserver(forName: UIWindow.keyboardWillShowNotification, object: nil, queue: nil) { (nc) in
            self.view.frame.origin.y = -100
        }
        //Передвигает экран обратно
        NotificationCenter.default.addObserver(forName: UIWindow.keyboardDidHideNotification, object: nil, queue: nil) { (nc) in
            self.view.frame.origin.y = 0.0
        }
   
    }
 
    //SegmentControl
    func segmentControlView()
    {
        let array = ["Sign in","Registration"]
        regitrationSegmentController = UISegmentedControl(items: array)
        let frame = CGRect(x: view.center.x - 125, y: 150, width: 250, height: 30)
        regitrationSegmentController.frame = frame
        view.addSubview(regitrationSegmentController)
        regitrationSegmentController.selectedSegmentIndex = 0
    
    }
    
    //loginNameTextField
    func loginNameView()
    {
        let frame = CGRect(x: view.center.x - 125, y: 360, width: 250, height: 30)
        loginNameTextField.frame = frame
        loginNameTextField.borderStyle = .line
        loginNameTextField.placeholder = "Login"
        view.addSubview(loginNameTextField)
        loginNameTextField.tag = 1
        loginNameTextField.delegate = self
    }
    
    //loginNameTextField
    func passwordView()
    {
        let frame = CGRect(x: view.center.x - 125, y: 400, width: 250, height: 30)
        passwordTextField.frame = frame
        passwordTextField.borderStyle = .line
        passwordTextField.placeholder = "Password"
        passwordTextField.isSecureTextEntry = true
        view.addSubview(passwordTextField)
        passwordTextField.tag = 2
        passwordTextField.delegate = self
        
    }
    //   Нажатие на кнопку return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField.tag {
        case 1:
            passwordTextField.becomeFirstResponder()
        case 2:
            passwordTextField.resignFirstResponder()
        default:
            break
        }
        return true
        
    }
    //Кнопка
    func buttonView()
    {
        let frame = CGRect(x: view.center.x - 100, y: view.center.y, width: 200, height: 30)
        
        signButton.frame = frame
        signButton.setTitle("Sign", for: .normal)
        signButton.backgroundColor = .green
        //signButton.addTarget(self, action: #selector, for: .touchDown)
        view.addSubview(signButton)
    }
 
}
//Расширение, при которой клавиатура скрывается при нажатие вне текстфилда
extension UIViewController
{
    func hideKeyboard()
    {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }

    @objc func dismissKeyboard()
    {
        view.endEditing(true)
    }
}

