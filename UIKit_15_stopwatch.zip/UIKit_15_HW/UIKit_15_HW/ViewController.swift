//
//  ViewController.swift
//  UIKit_15_HW


import UIKit

class ViewController: UIViewController {
    var label = UILabel()
    var buttonPlay = UIButton()
    var buttonStop = UIButton()
    var timer = Timer()
    var time = 0
    var position = 0
    let imagePlay = UIImage(named: "play")
    let imagePause = UIImage(named: "pause")
    let imageStop = UIImage(named: "stop")

    override func viewDidLoad() {
        super.viewDidLoad()
        createLabel()
        createButtonPlay()
        createButtonStop()
    }
    
    //create label (Timer)
    func createLabel() {
        label.frame = CGRect(x: 0, y: 150, width: 200, height: 40)
        label.center.x = view.center.x
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 30)
        label.text = createLabelText()
        view.addSubview(label)
    }
    
    //create playButton
    func createButtonPlay(){
        buttonPlay.frame = CGRect(x: 100, y: 300, width: 100, height: 100)
        if position == 0 {
            buttonPlay.setImage(imagePlay, for: .normal)
        } else {
            buttonPlay.setImage(imagePause, for: .normal)
        }
        buttonPlay.addTarget(self, action: #selector(playPause(sender:)), for: .touchUpInside)
        view.addSubview(buttonPlay)
    }
    @objc func playPause(sender:UIButton) {
        if position == 0 {
            playTimer()
            position = 1
            buttonPlay.setImage(imagePause, for: .normal)
        } else {
            pauseTimer()
            position = 0
            buttonPlay.setImage(imagePlay, for: .normal)
        }
    }
    
    //create stopButton
    func createButtonStop(){
        buttonStop.frame = CGRect(x: UIScreen.main.bounds.width - 200, y: 300, width: 100, height: 100)
        buttonStop.setImage(imageStop, for: .normal)
        view.addSubview(buttonStop)
        buttonStop.addTarget(self, action: #selector(stop(sender:)), for: .touchUpInside)
        position = 0
    }
    @objc func stop (sender:UIButton) {
        stopTimer()
        buttonPlay.setImage(imagePlay, for: .normal)
        position = 0
    }

    //Functions play, pause, stop
    func playTimer() {
        if position == 0 {
         timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.action), userInfo: nil, repeats: true)
        } else {
           timer.invalidate()
        }
    }

    func pauseTimer() {
        timer.invalidate()
    }
    
    func stopTimer() {
        time = 0
        timer.invalidate()
        label.text = createLabelText()
    }
    
    @objc func action() {
        time += 1
        label.text = createLabelText()
    }
    //createTextLabel
    func createLabelText() -> String {
        var dataArray:[Int] = [0,0,0]
        dataArray[0] = time / 3600
        dataArray[1] = time / 60
        dataArray[2] = time % 60
        let text = String(dataArray[0]) + ":" + String(dataArray[1]) + ":" + String(dataArray[2])
        return text
    }
}

