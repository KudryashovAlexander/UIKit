//
//  ViewController.swift
//  UIKit_17_HW
//
/*
 1. Повторите то, что есть в видео.
 2. Создать форму заполнения анкеты в свободной форме, анкета должна быть по высоте больше чем экран
 3. Поместить форму из п2 на UIScrollVIew
 4. Если клавиатуры выезжает (при заполнение TextField допустим) увеличить ScrollVIew на размер клавиатуры
 
 Дополнительно:
 1. Добавить возможность загрузки фото с камеры или фотопленки
 2. С помощью ScrollView реализовать листание фото
 */

import UIKit

private var globalNumberZero: Int = 250
private var globalBetween: Int = 50

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //ScrollView
    var myScrollView = UIScrollView()
    
    //ImageView
    var myPhotoImageView = UIImageView()
    
    //Button add photo
    var addButton = UIButton()
    
    //Label
    var labelName = UILabel()
    var labelFamily = UILabel()
    var labelAge = UILabel()
    var labelPostZone = UILabel()
    var labelCountry = UILabel()
    var labelCity = UILabel()
    var labelStreet = UILabel()
    var labelNumberHome = UILabel()
    var labelProfession = UILabel()
    var labelTelephone = UILabel()
    var labelNational = UILabel()
    var labelFavoriteAnimal = UILabel()
    
    //TextField
    var textFieldName = UITextField()
    var textFieldFamily = UITextField()
    var textFieldAge = UITextField()
    var textFieldPostZone = UITextField()
    var textFieldCountry = UITextField()
    var textFieldCity = UITextField()
    var textFieldStreet = UITextField()
    var textFieldNumberHome = UITextField()
    var textFieldProfession = UITextField()
    var textFieldTelephone = UITextField()
    var textFieldNational = UITextField()
    var textFieldFavoriteAnimal = UITextField()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyBoard()
        
        createScrollView()
        createImage()
        createAddButton()
        
        createLabel(nameLabel: labelName, text: "Name", y: globalNumberZero + globalBetween * 0)
        createLabel(nameLabel: labelFamily, text: "Family", y: globalNumberZero + globalBetween * 1)
        createLabel(nameLabel: labelAge, text: "Age", y: globalNumberZero + globalBetween * 2)
        createLabel(nameLabel: labelPostZone, text: "Post Zone", y: globalNumberZero + globalBetween * 3)
        createLabel(nameLabel: labelCountry, text: "Country", y: globalNumberZero + globalBetween * 4)
        createLabel(nameLabel: labelCity, text: "City", y: globalNumberZero + globalBetween * 5)
        createLabel(nameLabel: labelStreet, text: "Street", y: globalNumberZero + globalBetween * 6)
        createLabel(nameLabel: labelNumberHome, text: "Home Number", y: globalNumberZero + globalBetween * 7)
        createLabel(nameLabel: labelProfession, text: "Profession", y: globalNumberZero + globalBetween * 8)
        createLabel(nameLabel: labelTelephone, text: "Telephone", y: globalNumberZero + globalBetween * 9)
        createLabel(nameLabel: labelNational, text: "National", y: globalNumberZero + globalBetween * 10)
        createLabel(nameLabel: labelFavoriteAnimal, text: "Favorite Animal", y: globalNumberZero + globalBetween * 11)

        createTextField(textField: textFieldName, text: "Name", y: globalNumberZero, tag: 1)
        createTextField(textField: textFieldFamily, text: "Family", y: globalNumberZero + globalBetween * 1, tag: 2)
        createTextField(textField: textFieldAge, text: "Age", y: globalNumberZero + globalBetween * 2, tag: 3)
        createTextField(textField: textFieldPostZone, text: "Post Zone", y: globalNumberZero + globalBetween * 3, tag: 4)
        createTextField(textField: textFieldCountry, text: "Country", y: globalNumberZero + globalBetween * 4, tag: 5)
        createTextField(textField: textFieldCity, text: "City", y: globalNumberZero + globalBetween * 5, tag: 6)
        createTextField(textField: textFieldStreet, text: "Street", y: globalNumberZero + globalBetween * 6, tag: 7)
        createTextField(textField: textFieldNumberHome, text: "Home number", y: globalNumberZero + globalBetween * 7, tag: 8)
        createTextField(textField: textFieldProfession, text: "Profession", y: globalNumberZero + globalBetween * 8, tag: 9)
        createTextField(textField: textFieldTelephone, text: "Telephone", y: globalNumberZero + globalBetween * 9, tag: 10)
        createTextField(textField: textFieldNational, text: "National", y: globalNumberZero + globalBetween * 10, tag: 11)
        createTextField(textField: textFieldFavoriteAnimal, text: "Favorite Animal", y: globalNumberZero + globalBetween * 11, tag: 12)

        //Notification
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)
 
    }

    //MARK: - Function Create View
    //Create Labels
    func createLabel(nameLabel: UILabel, text: String, y: Int) {
        let frame = CGRect(x: 20, y: y, width: 120, height: globalBetween/2)
        nameLabel.frame = frame
        nameLabel.text = text
        nameLabel.textColor = .black
        nameLabel.textAlignment = .left
        myScrollView.addSubview(nameLabel)

    }
    
    //create Scroll View
    func createScrollView() {
        let frame = CGRect(x: 0, y: 0, width: Int(view.bounds.width), height: Int(view.bounds.height))
        myScrollView.frame = frame
        let size = CGSize(width: Int(view.bounds.width), height: Int(view.bounds.height) + 300)
        myScrollView.contentSize = size
        view.addSubview(myScrollView)
       
        
    }
    //create TextField
    func createTextField(textField: UITextField, text: String, y: Int, tag: Int) {
        let frame = CGRect(x: 160, y: y, width: Int(view.bounds.width) - 180, height: globalBetween/2)
        textField.frame = frame
        textField.placeholder = text
        textField.borderStyle = .line
        textField.tag = tag
        textField.delegate = self
        myScrollView.addSubview(textField)
    }
    //create Image
    func createImage() {
        let image = UIImage(named: "no_image")
        myPhotoImageView.image = image
        let frame = CGRect(x: 20, y: 50, width: Int(view.bounds.width)-160, height: 160)
        myPhotoImageView.frame = frame
        myPhotoImageView.center.x = view.center.x
        myPhotoImageView.contentMode = .scaleAspectFit
        myScrollView.addSubview(myPhotoImageView)
    }
    
    //create addButton
    func createAddButton(){
        addButton = UIButton.init(type: .contactAdd)
        let frame = CGRect(x: Int(view.bounds.width)-60, y: 0, width: 30, height: 30)
        addButton.frame = frame
        addButton.center.y = myPhotoImageView.center.y
        addButton.addTarget(self, action: #selector(addPhotoImage(sender:)), for: .touchUpInside)
        myScrollView.addSubview(addButton)
    }
    @objc func addPhotoImage(sender:UIButton) {
        if sender == addButton {
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                imagePicker.allowsEditing = true
                self.present(imagePicker, animated: true, completion: nil)
            }
            
        }
    }
    //MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        myPhotoImageView.image = info[.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
    }

     //MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField.tag {
        case 1:
            textFieldFamily.becomeFirstResponder()
        case 2:
            textFieldAge.becomeFirstResponder()
        case 3:
            textFieldPostZone.becomeFirstResponder()
        case 4:
            textFieldCountry.becomeFirstResponder()
        case 5:
            textFieldCity.becomeFirstResponder()
        case 6:
            textFieldStreet.becomeFirstResponder()
        case 7:
            textFieldNumberHome.becomeFirstResponder()
        case 8:
            textFieldProfession.becomeFirstResponder()
        case 9:
            textFieldTelephone.becomeFirstResponder()
        case 10:
            textFieldNational.becomeFirstResponder()
        case 11:
            textFieldFavoriteAnimal.becomeFirstResponder()
        case 12:
            textFieldFavoriteAnimal.resignFirstResponder()
        default:
            break
        }
        return true
    }
    
    
    //функция прокрутки при появлении клавиатуры
    @objc func keyboardWillShow(notification:NSNotification){
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.myScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        myScrollView.contentInset = contentInset
    }
    //Функция при исчезновении клавиатуры
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        myScrollView.contentInset = contentInset
    }
}

// функция скрытия клавиатуры при нажатии вне текстфилда
extension ViewController {
    func hideKeyBoard() {
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dissMissKeyboard))
        view.addGestureRecognizer(tap)
    }
    @objc func dissMissKeyboard() {
        view.endEditing(true)

    }
}
